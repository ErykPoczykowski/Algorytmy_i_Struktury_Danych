﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace najdluzszy_podciag
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void generuj_Click(object sender, EventArgs e)
        {
            string tekst1 = text1.Text.PadLeft(1);
            string tekst2 = text2.Text.PadLeft(1);
            int dl1 = tekst1.Length;
            int dl2 = tekst2.Length;


            int[,] tab = new int[dl1, dl2];
            for(int i = 1;i<dl1;i++)
            {
                for (int j = 1; j < dl2; j++)
                {
                    if(tekst1[i]== tekst1[j])
                    {
                        tab[i, j] = tab[i - 1, j - 1] + 1;
                    }
                    else
                    {
                        tab[i, j] = Math.Max(tab[i - 1, j], tab[i, j - 1]);
                    }
                }
            }
            int k=0, l=0;
            int wsk = tab[k, l];
            while (k >= 0 && l>=0)
            {
                if (tab[k-1,l] == wsk)
                {
                    wsk = tab[k - 1, l];
                    k--;
                }
                else if (tab[k, l-1] == wsk)
                {
                    wsk = tab[k, l-1];
                    l--;
                }
                else
                {
                    wsk = tab[k - 1, l - 1];
                    wynik
                }

            }

        }
    }
}
