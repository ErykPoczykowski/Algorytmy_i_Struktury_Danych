﻿namespace listy_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddFirst = new System.Windows.Forms.Button();
            this.btnAddLast = new System.Windows.Forms.Button();
            this.btnRemoveFirst = new System.Windows.Forms.Button();
            this.btnRemoveLast = new System.Windows.Forms.Button();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.count_display = new System.Windows.Forms.Label();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.BSTInput = new System.Windows.Forms.TextBox();
            this.btBSTInput = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btPre = new System.Windows.Forms.Button();
            this.tBPre = new System.Windows.Forms.TextBox();
            this.tBIn = new System.Windows.Forms.TextBox();
            this.tBPost = new System.Windows.Forms.TextBox();
            this.btIn = new System.Windows.Forms.Button();
            this.btPost = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAddFirst
            // 
            this.btnAddFirst.Location = new System.Drawing.Point(93, 62);
            this.btnAddFirst.Name = "btnAddFirst";
            this.btnAddFirst.Size = new System.Drawing.Size(160, 24);
            this.btnAddFirst.TabIndex = 0;
            this.btnAddFirst.Text = "Add First";
            this.btnAddFirst.UseVisualStyleBackColor = true;
            // 
            // btnAddLast
            // 
            this.btnAddLast.Location = new System.Drawing.Point(286, 64);
            this.btnAddLast.Name = "btnAddLast";
            this.btnAddLast.Size = new System.Drawing.Size(151, 22);
            this.btnAddLast.TabIndex = 1;
            this.btnAddLast.Text = "Add Last";
            this.btnAddLast.UseVisualStyleBackColor = true;
            // 
            // btnRemoveFirst
            // 
            this.btnRemoveFirst.Location = new System.Drawing.Point(452, 65);
            this.btnRemoveFirst.Name = "btnRemoveFirst";
            this.btnRemoveFirst.Size = new System.Drawing.Size(146, 22);
            this.btnRemoveFirst.TabIndex = 2;
            this.btnRemoveFirst.Text = "Remove First";
            this.btnRemoveFirst.UseVisualStyleBackColor = true;
            // 
            // btnRemoveLast
            // 
            this.btnRemoveLast.Location = new System.Drawing.Point(604, 64);
            this.btnRemoveLast.Name = "btnRemoveLast";
            this.btnRemoveLast.Size = new System.Drawing.Size(134, 24);
            this.btnRemoveLast.TabIndex = 3;
            this.btnRemoveLast.Text = "Remove Last";
            this.btnRemoveLast.UseVisualStyleBackColor = true;
            // 
            // txtDisplay
            // 
            this.txtDisplay.Location = new System.Drawing.Point(178, 92);
            this.txtDisplay.Multiline = true;
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.Size = new System.Drawing.Size(612, 50);
            this.txtDisplay.TabIndex = 5;
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(93, 38);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(612, 23);
            this.txtInput.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(237, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(290, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Wpisz liczbę a następnie kliknij Add First lub Add Last:";
            // 
            // count_display
            // 
            this.count_display.AutoSize = true;
            this.count_display.Location = new System.Drawing.Point(58, 89);
            this.count_display.Name = "count_display";
            this.count_display.Size = new System.Drawing.Size(114, 15);
            this.count_display.TabIndex = 8;
            this.count_display.Text = "Liczba elementów: 0";
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(196, 174);
            this.treeView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(592, 201);
            this.treeView1.TabIndex = 12;
            // 
            // BSTInput
            // 
            this.BSTInput.Location = new System.Drawing.Point(32, 174);
            this.BSTInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BSTInput.Name = "BSTInput";
            this.BSTInput.Size = new System.Drawing.Size(158, 23);
            this.BSTInput.TabIndex = 13;
            // 
            // btBSTInput
            // 
            this.btBSTInput.Location = new System.Drawing.Point(32, 201);
            this.btBSTInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btBSTInput.Name = "btBSTInput";
            this.btBSTInput.Size = new System.Drawing.Size(158, 38);
            this.btBSTInput.TabIndex = 14;
            this.btBSTInput.Text = "Dodaj do drzewka BST";
            this.btBSTInput.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(354, -5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 21);
            this.label2.TabIndex = 15;
            this.label2.Text = "List, Node";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(417, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 21);
            this.label3.TabIndex = 16;
            this.label3.Text = "BST, NodeT";
            // 
            // btPre
            // 
            this.btPre.Location = new System.Drawing.Point(93, 415);
            this.btPre.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btPre.Name = "btPre";
            this.btPre.Size = new System.Drawing.Size(104, 24);
            this.btPre.TabIndex = 17;
            this.btPre.Text = "PreOrder";
            this.btPre.UseVisualStyleBackColor = true;
            // 
            // tBPre
            // 
            this.tBPre.Location = new System.Drawing.Point(31, 388);
            this.tBPre.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tBPre.Name = "tBPre";
            this.tBPre.Size = new System.Drawing.Size(249, 23);
            this.tBPre.TabIndex = 20;
            // 
            // tBIn
            // 
            this.tBIn.Location = new System.Drawing.Point(285, 388);
            this.tBIn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tBIn.Name = "tBIn";
            this.tBIn.Size = new System.Drawing.Size(261, 23);
            this.tBIn.TabIndex = 1;
            // 
            // tBPost
            // 
            this.tBPost.Location = new System.Drawing.Point(552, 388);
            this.tBPost.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tBPost.Name = "tBPost";
            this.tBPost.Size = new System.Drawing.Size(236, 23);
            this.tBPost.TabIndex = 0;
            // 
            // btIn
            // 
            this.btIn.Location = new System.Drawing.Point(364, 415);
            this.btIn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btIn.Name = "btIn";
            this.btIn.Size = new System.Drawing.Size(94, 24);
            this.btIn.TabIndex = 21;
            this.btIn.Text = "InOrder";
            this.btIn.UseVisualStyleBackColor = true;
            // 
            // btPost
            // 
            this.btPost.Location = new System.Drawing.Point(632, 415);
            this.btPost.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btPost.Name = "btPost";
            this.btPost.Size = new System.Drawing.Size(89, 24);
            this.btPost.TabIndex = 22;
            this.btPost.Text = "PostOrder";
            this.btPost.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btPost);
            this.Controls.Add(this.btIn);
            this.Controls.Add(this.tBPost);
            this.Controls.Add(this.tBIn);
            this.Controls.Add(this.tBPre);
            this.Controls.Add(this.btPre);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btBSTInput);
            this.Controls.Add(this.BSTInput);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.count_display);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.btnRemoveLast);
            this.Controls.Add(this.btnRemoveFirst);
            this.Controls.Add(this.btnAddLast);
            this.Controls.Add(this.btnAddFirst);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button btnAddFirst;
        private Button btnAddLast;
        private Button btnRemoveFirst;
        private Button btnRemoveLast;
        private TextBox txtDisplay;
        private TextBox txtInput;
        private Label label1;
        private Label count_display;
        private TreeView treeView1;
        private TextBox BSTInput;
        private Button btBSTInput;
        private Label label2;
        private Label label3;
        private Button btPre;
        private TextBox tBPre;
        private TextBox tBIn;
        private TextBox tBPost;
        private Button btIn;
        private Button btPost;
    }
}
