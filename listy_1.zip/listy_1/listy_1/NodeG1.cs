﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace listy_1
{
    internal class NodeG1
    {
        int data;
    }
}
