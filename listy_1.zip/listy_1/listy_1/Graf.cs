﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace listy_1
{
    internal class Graf
    {
        List<NodeG> nodes = new List<NodeG>();
        List<NodeG> Wszerz (NodeG start)
        {
            List<NodeG> odwiedzone = new List<NodeG>() {start};
            for(int i = 0;i < odwiedzone.Count; i++)
            {
                var tmp = odwiedzone[i];
                for(int j = 0; j < tmp.sasiedzi.Count;j++)
                {
                    if (!odwiedzone.Contains(tmp.sasiedzi[j]))
                    {
                        odwiedzone.Add(tmp.sasiedzi[j]);
                    }
                }
            
            }
            return odwiedzone;
        }
       
    }
}
