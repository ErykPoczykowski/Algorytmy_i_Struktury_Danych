﻿namespace listy_1
{
    public class NodeT
    {
        public NodeT rodzic;
        public NodeT lewe;
        public NodeT prawe;
        public int data;

        public NodeT(int liczba)
        {
            this.data = liczba;
        }

        public override string ToString()
        {
            return this.data.ToString();
        }
        public int liczbaDzieci()
        {
            int wynik = 0;
            if (this.lewe != null)
            {
                wynik++;
            }
            if (this.prawe != null)
            {
                wynik++;
            }
            return wynik;
        }
        public void Polaczlewe(NodeT dziecko)
        {
            this.lewe = dziecko;
            if (dziecko != null)
                dziecko.rodzic = this;

        }
        public void PolaczPrawe(NodeT dziecko)
        {
            this.prawe = dziecko;
            if (dziecko != null)
                dziecko.rodzic = this;

        }
    }
}
