using System.Drawing;
using System.Text;

namespace listy_1
{
    public partial class Form1 : Form
    {
        private List myList;
        private BST bst;

        public Form1()
        {
            InitializeComponent();
            myList = new List();
        }

        BST tree1 = new BST();

        //Sekcja BST --------------------------------------------------
        void ShowNode(NodeT nodeT, TreeNode treeNode)
        {
            treeNode.Text += nodeT.data;
            if (nodeT.lewe != null)
            {
                ShowNode(nodeT.lewe, treeNode.Nodes.Add("Lewe: "));
            }
            if (nodeT.prawe != null)
            {
                ShowNode(nodeT.prawe, treeNode.Nodes.Add("Prawe: "));
            }

        }
        void Show(BST tree)
        {
            treeView1.Nodes.Clear();
            ShowNode(tree.root, treeView1.Nodes.Add("Korzen: "));
            treeView1.ExpandAll();
        }

        private void btBSTInput_Click(object sender, EventArgs e)
        {
            var liczba = int.Parse(BSTInput.Text);
            tree1.Add(liczba);
            BSTInput.Clear();
            treeView1.Nodes.Clear();
            Show(tree1);
        }

        void PreOrder(NodeT x)
        {
            if (x == null)
                return;
            tBPre.Text += x.data.ToString();
            tBPre.Text += " ";
            PreOrder(x.lewe);
            PreOrder(x.prawe);
        }

        void InOrder(NodeT x)
        {
            if (x == null)
                return;
            InOrder(x.lewe);
            tBIn.Text += x.data.ToString();
            tBIn.Text += " ";
            InOrder(x.prawe);
        }

        void PostOrder(NodeT x)
        {
            if (x == null)
                return;

            PostOrder(x.lewe);
            PostOrder(x.prawe);
            tBPost.Text += x.data.ToString();
            tBPost.Text += " ";
        }
        private void btPre_Click(object sender, EventArgs e)
        {
            tBPre.Clear();
            PreOrder(tree1.root);
        }

        private void btIn_Click(object sender, EventArgs e)
        {
            tBIn.Clear();
            InOrder(tree1.root);
        }

        private void btPost_Click(object sender, EventArgs e)
        {
            tBPost.Clear();
            PostOrder(tree1.root);
        }

        //-------------------------------------------------------------
        //Sekcja List -------------------------------------------------

        private void btnAddFirst_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtInput.Text, out int value))
            {
                Node newNode = new Node(value);
                myList.AddFirst(newNode);
                txtInput.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid integer.");
            }
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        private void btnAddLast_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtInput.Text, out int value))
            {
                Node newNode = new Node(value);
                myList.AddLast(newNode);
                txtInput.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid integer.");
            }
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        private void btnRemoveFirst_Click(object sender, EventArgs e)
        {
            myList.RemoveFirst();
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        private void btnRemoveLast_Click(object sender, EventArgs e)
        {
            myList.RemoveLast();
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        private string GetListContent()
        {
            var content = new StringBuilder();
            Node current = myList.Head;
            while (current != null)
            {
                content.Append("[ ");
                content.Append(DisplayNodeData(current));
                content.Append(" ] -> ");
                current = current.Next;
            }
            content.Append("null");
            return content.ToString();
        }

        private string DisplayNodeData(Node node)
        {
            return node.Data.ToString();
        }

        //---------------------------------------------------------
    }
}
