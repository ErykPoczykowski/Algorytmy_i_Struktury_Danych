﻿namespace listy_1
{
    internal class Node
    {
        public Node Next { get; set; }
        public Node Prev { get; set; }
        public int Data { get; set; }

        public Node(int data) {
            Data = data;
            Next = null;
            Prev = null;
        }
    }
}
