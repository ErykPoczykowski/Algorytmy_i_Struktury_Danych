﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace listy_1
{
    internal class Graf1
    {
        List<NodeG1> nodes = new();
        List<Edge> edges = new();
        GrafG1(Edge k)
        {
            
        }
        void Add(Edge k)
        {
            int wynik = 0;
            if (!this.nodes.Contains(k.start))
            {
                wynik++;
            }
            if (!this.nodes.Contains(k.end))
            {
                wynik++;
            }
            return wynik;
        }
        
        public int IleNowychWezlow(Edge k)
        {
            int wynik = 0;
            if(!this.nodes.Contains(k.start))
            {
                wynik++;
            }
            if (!this.nodes.Contains(k.end))
            {
                wynik++;
            }
            return wynik;

        }
        void Join(GrafG1 g1)
        {
            for(int i = 0;i<g1.edges.Count; i++)
            {
                this.Add(g1.edges[i]);
            }
        }

    }
}
