﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testowy
{
    public partial class Form1 : Form
    {
        private int[] przekonwertowane;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void konwertuj_Click(object sender, EventArgs e)
        {
            string tekst = wpisz.Text;
            string[] konwertowane = tekst.Split(',');
            przekonwertowane = new int[konwertowane.Length];
            for (int i = 0; i < konwertowane.Length; i++)
            {
                przekonwertowane[i] = Int32.Parse(konwertowane[i]);
            }
        }

        private void sort_B_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < przekonwertowane.Length - 1; i++)
            {
                for (int j = 0; j < przekonwertowane.Length - 1; j++)
                {
                    if (przekonwertowane[j] > przekonwertowane[j + 1])
                    {
                        int temp = przekonwertowane[j + 1];
                        przekonwertowane[j + 1] = przekonwertowane[j];
                        przekonwertowane[j] = temp;
                    }
                }
            }
            string Wynik = string.Join(",", przekonwertowane);
            wynik.Text = Wynik;

        }

        private void sort_W_Click(object sender, EventArgs e)
        {
            for (int i = 1; i < przekonwertowane.Length; i++)
            {
                int temp = przekonwertowane[i];
                int znacznik = 0;
                for (int j = i - 1; j >= 0 && znacznik != 1;)
                {
                    if (temp < przekonwertowane[j])
                    {
                        przekonwertowane[j + 1] = przekonwertowane[j];
                        j--;
                        przekonwertowane[j + 1] = temp;
                    }
                    else znacznik = 1;
                }
            }
            string Wynik = string.Join(",", przekonwertowane);
            wynik.Text = Wynik;
        }
        private int Maksymalna_wartosc(int[] tab)
        {
            var max = tab[0];
            for (int i = 1; i < przekonwertowane.Length; i++)
                if (tab[i] > max)
                    max = tab[i];
            return max;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var max = Maksymalna_wartosc(przekonwertowane);
            var wystapienia = new int[max + 1];
            for (int i = 0; i < max + 1; i++)
            {
                wystapienia[i] = 0;
            }
            for (int i = 0; i < przekonwertowane.Length; i++)
            {
                wystapienia[przekonwertowane[i]]++;
            }
            for (int i = 0, j = 0; i <= max; i++)
            {
                while (wystapienia[i] > 0)
                {
                    przekonwertowane[j] = i;
                    j++;
                    wystapienia[i]--;
                }
            }
            string Wynik = string.Join(",", przekonwertowane);
            wynik.Text = Wynik;
        }
    }
}
