﻿namespace testowy
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.wpisz = new System.Windows.Forms.TextBox();
            this.konwertuj = new System.Windows.Forms.Button();
            this.wynik = new System.Windows.Forms.TextBox();
            this.sort_B = new System.Windows.Forms.Button();
            this.sort_W = new System.Windows.Forms.Button();
            this.sort_S = new System.Windows.Forms.Button();
            this.sort_Z = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wpisz
            // 
            this.wpisz.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wpisz.Location = new System.Drawing.Point(229, 38);
            this.wpisz.Name = "wpisz";
            this.wpisz.Size = new System.Drawing.Size(310, 38);
            this.wpisz.TabIndex = 0;
            // 
            // konwertuj
            // 
            this.konwertuj.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.konwertuj.Location = new System.Drawing.Point(305, 97);
            this.konwertuj.Name = "konwertuj";
            this.konwertuj.Size = new System.Drawing.Size(150, 46);
            this.konwertuj.TabIndex = 2;
            this.konwertuj.Text = "Konwertuj";
            this.konwertuj.UseVisualStyleBackColor = true;
            this.konwertuj.Click += new System.EventHandler(this.konwertuj_Click);
            // 
            // wynik
            // 
            this.wynik.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wynik.Location = new System.Drawing.Point(41, 263);
            this.wynik.Name = "wynik";
            this.wynik.Size = new System.Drawing.Size(716, 38);
            this.wynik.TabIndex = 3;
            // 
            // sort_B
            // 
            this.sort_B.Location = new System.Drawing.Point(41, 386);
            this.sort_B.Name = "sort_B";
            this.sort_B.Size = new System.Drawing.Size(87, 32);
            this.sort_B.TabIndex = 4;
            this.sort_B.Text = "Bąbelkowe";
            this.sort_B.UseVisualStyleBackColor = true;
            this.sort_B.Click += new System.EventHandler(this.sort_B_Click);
            // 
            // sort_W
            // 
            this.sort_W.Location = new System.Drawing.Point(157, 386);
            this.sort_W.Name = "sort_W";
            this.sort_W.Size = new System.Drawing.Size(85, 32);
            this.sort_W.TabIndex = 5;
            this.sort_W.Text = "Wstawianie";
            this.sort_W.UseVisualStyleBackColor = true;
            this.sort_W.Click += new System.EventHandler(this.sort_W_Click);
            // 
            // sort_S
            // 
            this.sort_S.Location = new System.Drawing.Point(273, 386);
            this.sort_S.Name = "sort_S";
            this.sort_S.Size = new System.Drawing.Size(89, 32);
            this.sort_S.TabIndex = 6;
            this.sort_S.Text = "Scalanie";
            this.sort_S.UseVisualStyleBackColor = true;
            // 
            // sort_Z
            // 
            this.sort_Z.Location = new System.Drawing.Point(398, 386);
            this.sort_Z.Name = "sort_Z";
            this.sort_Z.Size = new System.Drawing.Size(91, 32);
            this.sort_Z.TabIndex = 7;
            this.sort_Z.Text = "Zliczanie";
            this.sort_Z.UseVisualStyleBackColor = true;
            this.sort_Z.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.sort_Z);
            this.Controls.Add(this.sort_S);
            this.Controls.Add(this.sort_W);
            this.Controls.Add(this.sort_B);
            this.Controls.Add(this.wynik);
            this.Controls.Add(this.konwertuj);
            this.Controls.Add(this.wpisz);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox wpisz;
        private System.Windows.Forms.Button konwertuj;
        private System.Windows.Forms.TextBox wynik;
        private System.Windows.Forms.Button sort_B;
        private System.Windows.Forms.Button sort_W;
        private System.Windows.Forms.Button sort_S;
        private System.Windows.Forms.Button sort_Z;
    }
}

