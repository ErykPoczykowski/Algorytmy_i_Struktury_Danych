﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace listy_1
{
    internal class NodeGS : NodeG2
    {
        public char symbol;
    }
}
