﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace listy_1
{
    internal class GrafG1
    {
        Element()
        {
            NodeG1 wezel;
            int kolejny;
            NodeG1 poprzednik;
        }
        List<NodeG1> nodes = new();
        List<Edge> edges = new();
        List<Element>;
        Dictionary<NodeG1,Element>;

        GrafG1(Edge k)
        {
            Add(k);
            this.edges.Add(k);
        }

        void Add(Edge k)
        {
            int wynik = 0;
            if (!this.nodes.Contains(k.start))
            {
                wynik++;
            }
            if (!this.nodes.Contains(k.end))
            {
                wynik++;
            }
        }
        
        public int IleNowychWezlow(Edge k)
        {
            int wynik = 0;
            if(!this.nodes.Contains(k.start))
            {
                wynik++;
            }
            if (!this.nodes.Contains(k.end))
            {
                wynik++;
            }
            return wynik;

        }
        void Join(GrafG1 g1)
        {
            for(int i = 0;i<g1.edges.Count; i++)
            {
                this.Add(g1.edges[i]);
            }
        }
        list<Element> AlgorytmDikstry(NodeG1 start)
        {
            var tabelka = this.PrzygotujTabelke(start);
            var S = new List<NodeG1>();
            while
            {

            }


        }

    }
}
