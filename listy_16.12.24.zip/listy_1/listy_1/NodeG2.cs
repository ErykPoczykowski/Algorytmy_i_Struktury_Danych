﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace listy_1
{
    internal class NodeG2
    {
        public char symbol;
        public NodeT rodzic;
        public NodeT lewe;
        public NodeT prawe;
        public int data;
        public NodeG2(int czestosc)
        {
            this.data = czestosc;
        }
        public List<bool> przejscie(char symbol,List<bool> data)
        {
            if(prawe == null && lewe == null)
            {
                if(symbol.Equals(this.symbol))
                {
                    return data;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                List<bool> lewe = null;
                List<bool> prawe = null;
                if(lewe != null)
                {
                    List<bool> leweTrasa = new List<bool>();
                    leweTrasa.AddRange(data);
                    leweTrasa.Add(false);

                    lewe = lewe.przejscie(symbol, leweTrasa);
                }
                if (prawe != null)
                {
                    List<bool> praweTrasa = new List<bool>();
                    praweTrasa.AddRange(data);
                    praweTrasa.Add(false);

                    lewe = lewe.przejscie(symbol, praweTrasa);
                }
                if(lewe != null)
                {
                    return lewe;
                }
                else
                {
                    return prawe;
                }
            }
        }
        // var newlist<NodeG>()
        // List.OrderBy(n => n.data).ThenBy(n=>n.GetType() = typeof(NodeGS)?0:1).Tolist()
    }
}
   
